void main() {
     TRISB=0;
     TRISD=1;
     TRISE=0;
     
     while(1)   {
     
         if(PORTD.RD0==0){
             PORTE.RE0=1;
             PORTB.RB0=1;
         }
         
         else{
             PORTE.RE0=0;
             PORTB.RB0=0;
         }
     }
     
     
     
}