void main() {

     //trafic light up
     TRISB.RB0=0;
     TRISB.RB1=0;
     TRISB.RB2=0;
     
     PORTC=0;
     
     //Trafic light right
     TRISB.RB4=0;
     TRISB.RB5=0;
     TRISB.RB6=0;
     
     PORTB=0;

     //Trafic light down
     TRISC.RC0=0;
     TRISC.RC1=0;
     TRISC.RC2=0;
     
     PORTC=0;
     
     //Trafic light left
     TRISD.RD0=0;
     TRISD.RD1=0;
     TRISD.RD2=0;
     
     PORTD=0;

     while(1)
     {
     
     //RED
       PORTB.RB2=1;
       PORTC.RC0=1;
       PORTD.RD2=1;
       PORTB.RB4=1;
       delay_ms(200);
       PORTB.RB2=0;
       PORTC.RC0=0;
       PORTD.RD2=0;
       PORTB.RB4=0;
       
     
      //ORANGE

       PORTB.RB1=1;
       PORTC.RC1=1;
       PORTB.RB5=1;
       PORTD.RD1=1;
       delay_ms(200);
       PORTB.RB1=0;
       PORTC.RC1=0;
       PORTB.RB5=0;
       PORTD.RD1=0;

       
      //GREEN
       PORTB.RB0=1;
       PORTC.RC2=1;
       PORTB.RB6=1;
       PORTD.RD0=1;
       delay_ms(200);
       PORTB.RB0=0;
       PORTC.RC2=0;
       PORTB.RB6=0;
       PORTD.RD0=0;
       
       
      //ORANGE
       PORTB.RB1=1;
       PORTC.RC1=1;
       PORTB.RB5=1;
       PORTD.RD1=1;
       delay_ms(200);
       PORTB.RB1=0;
       PORTC.RC1=0;
       PORTB.RB5=0;
       PORTD.RD1=0;
       


     
     
     
     
     
     }
     
     
     
}